# Contributing

- Join the [Discord](https://discord.gg/uhqx4Yr33j)

- Let us know what you are working on (for the spreadsheet)

- Fork the repo (or create a branch if you're invited)

- Open a PR once finished

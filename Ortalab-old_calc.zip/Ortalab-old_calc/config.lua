return {
    initial_setup_demo_3 = false,
	full_credits = false,
    artist_credits = true,
    placeholders = true,
    enhancement_skip = false,
    loteria_skip = false
}
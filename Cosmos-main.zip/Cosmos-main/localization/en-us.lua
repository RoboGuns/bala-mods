return {
    descriptions = {
        Joker = {
            cosmos_j_snowman_gain = {
                name = 'Snowman',
                text = {
                    "Gains {C:chips}+#2#{} Chips per card scored",
                    "After Joker reaches {C:chips}#4#{} Chips,",
                    "{C:chips}-#3#{} Chips per card scored",
                    "{C:inactive}(Currently {C:chips}#1#{C:inactive} Chips)"
                }
            },
            cosmos_j_snowman_melt = {
                name = 'Snowman',
                text = {
--                    "{C:inactive,s:0.7}The days are getting warmer...",
                    "{C:chips}-#3#{} Chips per card scored",
                    "{C:inactive}(Currently {C:chips}#1#{C:inactive} Chips)"
                }
            }
        }
    }
}

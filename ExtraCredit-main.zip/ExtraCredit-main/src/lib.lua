ExtraCredit = {}
ExtraCredit.INIT = {
    Jokers = {}
}
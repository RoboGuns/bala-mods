return {
    enable = true,
    keybinds = {
        dpleft = 'a',
        dpright = 'd',
        dpup = 'w',
        dpdown = 's',
        x = 'x',
        y = 'c',
        a = 'space',
        b = 'lshift',
        start = 'escape',
        triggerleft = 'q',
        triggerright = 'e',
        leftshoulder = 'z',
        rightshoulder = 'v',
        back = 'tab',
    },
}
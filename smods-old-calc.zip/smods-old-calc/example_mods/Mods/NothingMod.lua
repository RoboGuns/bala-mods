--- STEAMODDED HEADER
--- MOD_NAME: The Nothing Mod
--- MOD_ID: NothingMod
--- MOD_AUTHOR: [Steamo, TheVoid]
--- MOD_DESCRIPTION: This Mod doesn't do anything !

----------------------------------------------
------------MOD CODE -------------------------

----------------------------------------------
------------MOD CODE END----------------------
